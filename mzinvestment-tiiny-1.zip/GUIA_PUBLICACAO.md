# 📦 MZInvestment — Guia de Publicação

## ✅ Ficheiros incluídos neste pacote
- index.html       → Plataforma completa
- manifest.json    → Configuração PWA (instalável)
- sw.js            → Service Worker (funciona offline)
- icon-192.png     → Ícone da app (Android)
- icon-512.png     → Ícone da app (Play Store)
- icon-48/72/96/144.png → Ícones adicionais

---

## 🌐 PASSO 1 — Publicar o Link Online (Netlify) — GRATUITO

1. Vai a: https://netlify.com
2. Cria conta gratuita (usa o teu email)
3. Clica em "Add new site" → "Deploy manually"
4. Arrasta a PASTA completa "mzinvestment" para a área indicada
5. ✅ Em 30 segundos tens um link como:
   https://mzinvestment.netlify.app

### Personalizar o domínio (opcional):
- No painel Netlify → Site settings → Domain management
- Podes usar um domínio próprio como: www.mzinvestment.co.mz

---

## 📲 PASSO 2 — Instalar como App no Telemóvel (PWA)

### Android (Chrome):
1. Abre o link no Chrome
2. Aparece automaticamente um banner "Adicionar ao ecrã inicial"
3. Toca em "Instalar" → a app fica instalada como app nativa!

### iPhone (Safari):
1. Abre o link no Safari
2. Toca no botão de partilha (quadrado com seta)
3. Selecciona "Adicionar ao ecrã de início"
4. Toca "Adicionar" → instalada!

---

## 🤖 PASSO 3 — Publicar na Google Play Store

### Método recomendado: PWABuilder (GRATUITO)

1. Vai a: https://www.pwabuilder.com
2. Insere o teu link Netlify (ex: https://mzinvestment.netlify.app)
3. Clica "Start" → ele analisa automaticamente
4. Clica em "Package for stores" → "Google Play"
5. Descarrega o pacote Android (.aab)

### Para publicar na Play Store precisas de:
- Conta Google Play Developer: https://play.google.com/console
- Taxa única de registo: USD $25 (≈ 1.600 MT)
- Preencher formulário da app:
  - Nome: MZInvestment
  - Categoria: Finanças
  - Descrição da app
  - Capturas de ecrã (tira no telemóvel)
  - Ícone 512x512 (já incluído: icon-512.png)

### Tempo de aprovação:
- Google Play: 3 a 7 dias úteis

---

## 🍎 PASSO 4 — Publicar na App Store (iPhone) — Opcional

### Requisitos:
- Conta Apple Developer: USD $99/ano
- Mac com Xcode (ou serviço externo)
- Alternativa gratuita: distribuir via link Safari (PWA funciona perfeitamente)

---

## 🔐 Credenciais Admin (CONFIDENCIAL)
- Guarda estas credenciais em local seguro
- Não partilhar com ninguém

---

## 📞 Suporte técnico
Para qualquer dúvida sobre a publicação, contacta o suporte técnico.

---

## 🔄 Como actualizar a plataforma:
1. Faz as alterações no index.html
2. Vai ao Netlify → Deploys → "Deploy manually"
3. Arrasta o ficheiro actualizado
4. O link permanece o mesmo — utilizadores vêem as alterações automaticamente
